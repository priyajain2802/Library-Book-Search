<?php
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) )
exit();

function lbs_delete_data() {
    global $wpdb;

    $posts = get_posts( array(
        'numberposts' => -1,
        'post_type' => 'book',
        'post_status' => 'any' ) );

    foreach ( $posts as $post ){
        wp_delete_post( $post->ID, true );
    }
}

lbs_delete_data();

// Set global
global $wpdb;
// Delete terms
$wpdb->query( "
    DELETE FROM
    {$wpdb->terms}
    WHERE term_id IN
    ( SELECT * FROM (
        SELECT {$wpdb->terms}.term_id
        FROM {$wpdb->terms}
        JOIN {$wpdb->term_taxonomy}
        ON {$wpdb->term_taxonomy}.term_id = {$wpdb->terms}.term_id
        WHERE taxonomy IN('book_author', 'book_publisher')
    ) as T
    );
");
// Delete taxonomies
$wpdb->query( "DELETE FROM {$wpdb->term_taxonomy} WHERE IN('book_author', 'book_publisher')" );