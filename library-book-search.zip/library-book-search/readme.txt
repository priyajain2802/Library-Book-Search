=== Library Book Search ===
Contributors: Priya
Requires at least: 4.0
Donate link: #
Tested up to: 4.9
Requires PHP: 5.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A simple search plugin for book library. It will allow users to search books with book name, author, publisher, price and book ratings.

Donate link: #

Tags: book library, search books, books post type, ajax serach.

Requires at least: 3.5

Tested up to: 4.8

Stable tag: trunk

License: GPLv2 or later

License URI: http://www.gnu.org/licenses/gpl-2.0.html 


== Description ==

Library book serach plugin will allow users to save all the books in the back-end and display their list on the front end with advance filters.

Searching is based on wp ajax with book name, author, publisher, price and book ratings search.  

Users can customize books post types and they can add shortcode to provide book filter option on any page or post.


== Installation ==

1. Upload the entire **library-book-search** folder to the **/wp-content/plugins/** directory.
2. Activate the plugin through the **Plugins** menu in WordPress admin.
3. Go to the Books menu post and add the details according to the need.


== Screenshots ==

1. This screenshot refers the back-end functionality of this plugin. You just need to do manage books with categories on the back-end.

2. This is how it will apprear on the front end.

3. This is how your search result page will look with pagination.


== Frequently Asked Questions ==

= How to include more fields on the back-end?=

You can add your custom meta boxes and use them according to the need for Book post type.

== Suggestions ==

You are excited from the "Library Book Seach" plugin and want to contribute? Get involved at our [GitHub repository](https://github.com/priyajain2802/)

== Upgrade Notice ==

= 0.1 =

Starter version no upgrade is required.

== Changelog ==

= 1.0 Version 17/07/2018 =

= We Need Your Support =

It is really hard to continue development and support for this free plugin without contributions from users like you. If you are enjoying using our Library Book Search plugin and find it useful, then please consider [__Making a Donation__](https://github.com/priyajain2802/). Your donation will help us to encourage and support the plugin's continued development and better user support.