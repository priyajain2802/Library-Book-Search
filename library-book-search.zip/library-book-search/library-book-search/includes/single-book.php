<?php
/**
 * The template for displaying all single book posts.
 *
 */
get_header(); ?>
<div class="wrap single-book">
	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">

			<?php
			/* Start the Loop */
			while ( have_posts() ) : the_post();
				echo "<h2>".get_the_title()."</h2>";
				echo '<a href="'.get_the_permalink().'">'.the_post_thumbnail().'</a><br/></br>'; 
                

				$rating = get_post_meta(get_the_ID(),'lbs_ratings', true);

				// round down to get number of whole stars needed
				$totalstars = floor( $rating );
				$halfstar = round( $rating * 2 ) % 2;
				$stars = "";

				for( $i=0; $i<$totalstars; $i++ ){
				    $stars .= '<img src="'.plugin_dir_url("library-book-search/assets/images/",  __FILE__ ).'images/star.png" alt="Whole Star">';
				}
				//img tag for half star for decimal values
				if( $halfstar ){
				    $stars .= '<img src="'.plugin_dir_url("library-book-search/assets/images/",  __FILE__ ).'images/half-star.png" alt="Whole Star">';
				}

				echo 'Ratings: '.$stars.'</br>';
				echo "Price: ".get_post_meta(get_the_ID(), 'lbs_price', true)."<br/>";
                $book_publishers = wp_get_post_terms($post->ID, 'book_publisher', array("fields" => "all"));
				foreach($book_publishers as $bookpublisher) {
					echo "Book Publisher: ".$bookpublisher->name."</br>";
				}
				$book_authors = wp_get_post_terms($post->ID, 'book_author', array("fields" => "all"));
				foreach($book_authors as $book_author) {
					echo "Book Author: ".$book_author->name."</br>";
				}
				echo '<div class="content-div">';
				the_content();
				echo '</div>';
				// If comments are open or we have at least one comment, load up the comment template.
				if ( comments_open() || get_comments_number() ) :
					comments_template();
				endif;

				

			endwhile; // End of the loop.
			?>

		</main><!-- #main -->
	</div><!-- #primary -->
	<?php get_sidebar(); ?>
</div><!-- .wrap -->

<?php get_footer();
