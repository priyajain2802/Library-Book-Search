<?php if( !class_exists( 'library_book_search' ) ) {
	class library_book_search {
		/**
	     * Plugin search form
	     *
	     */
	    public function search_form(){
			?>
			<div class="container">
				<div class="heading" align="center"><h3>Book</h3></div>
				<div class="search-form-box">
					<div class="row">
						<form method="post" name="search_form" id="search-form">
							<div class="col-md-6">
						      <div class="form-group">
							    <label for="bookname">Book Name</label>
							    <input type="text" class="form-control" name="bookname" id="bookname" placeholder="Enter book name/keyword">
							</div>
							<div class="form-group">
								<label for="bookpublisher">Publisher</label>
								<select name="bookpublisher" class="form-control">
								<option value="">Select publisher</option>
								<?php 
									$args = array( 'post_type' => 'book'); global $post;
									$loop = new WP_Query( $args );
									while ( $loop->have_posts() ) : $loop->the_post(); 
										$book_publishers = wp_get_post_terms($post->ID, 'book_publisher', array("fields" => "all"));
										foreach($book_publishers as $bookpublisher) {
											echo "<option value=".$bookpublisher->slug.">".$bookpublisher->name."</option>";
										}
									endwhile;
								?> 
								</select> 
							</div>
							<div class="form-group">
						   	<label for="amount">Price range:</label>
					        	<!-- Other-->
							<div class="range-slider">
								<span class="range-min">0</span>
								<input name="bookprice" class="range-slider__range" type="range" value="0" min="0" max="3000" autocomplete="off">
								<span class="range-slider__value">0</span> </div>
							</div>
							<small id="bookprice" class="form-text text-muted">You can select range for prices.</small>
							</div>
						    <div class="col-md-6">
						       <div class="form-group">
							    	<label for="bookauthor">Book Author</label>
							    	<input type="text" class="form-control" id="bookauthor" name="bookauthor" placeholder="Enter book author">
							  	</div>
							  	<div class="form-group">
								    <label for="bookratings">Ratings</label>
								    <select name="bookratings" class="form-control" id="bookratings">
									<option value="">Select rating</option>
										<?php 
										for($i=1; $i<=5; $i++)
										{

										    echo "<option value=".$i.">".$i."</option>";
										}
										?> 
									</select> 
								</div>
							  	
							</div>
							  
							</div>
							<div class="col-md-12 center-block">
								<button type="submit" class="btn btn-lg btn-primary center-block" id="search-book" name="search" value="">Search</button>
								<span id="LoadingImage" class="loading-image" style="display: none">
								  <img src="<?php echo plugin_dir_url('library-book-search/assets/images/',  __FILE__ ); ?>/images/loader.gif" alt="Whole Star">
								</span>
							</div>
						</form>
					</div>
				</div>
			</div>			
			<?php
		}

		/*
		**Function to add pagination on book listing
		*/
		public function lbs_pagination( $query_wp ) 
		{
		    $pages = $query_wp->max_num_pages;
		    $big = 999999999; // need an unlikely integer
		    if ($pages > 1)
		    {
		        $page_current = max(1, get_query_var('paged'));
		        echo paginate_links(array(
		            'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
		            'format' => '?paged=%#%',
		            'current' => $page_current,
		            'total' => $pages,
		        ));
		    }
		}
		/*
		** Function to show book listing in a table
		*/
		public function book_listing(){ ?>
			<div class="container" id="resultdata">
				<table class="table table-striped table-bordered" id="tableData">                     
				    <div class="table responsive">
				        <thead>
				            <tr>
				              <th>No.</th>
				              <th>Name</th>
				              <th>Author</th>
				              <th>Publisher</th>
				              <th>Price</th>
				              <th>Ratings</th>	
				            </tr>
				        </thead>
				        <tbody class="searchresponse">
						<?php $j = 1; global $post;
						$paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;
						$loop = new WP_Query( array( 'post_type' => 'book',
								        'posts_per_page' => -1
								    )
								);
						if ( $loop->have_posts() ): 
						    while ( $loop->have_posts() ) : $loop->the_post();
						    	echo "<tr>"; 
								echo '<td>'.$j.'</td>';
								echo '<td><a href="'.get_the_permalink().'">'.get_the_title().'</a></td>';
								$book_author = wp_get_post_terms($post->ID, 'book_author', array("fields" => "names"));
								echo '<td>'.$book_author[0].'</td>';
								$book_publisher = wp_get_post_terms($post->ID, 'book_publisher', array("fields" => "names"));
								echo '<td>'.$book_publisher[0].'</td>';
								echo '<td>'.get_post_meta($post->ID,'lbs_price', true).'</td>';
						    	$rating = get_post_meta($post->ID,'lbs_ratings', true);

								// round down to get number of whole stars needed
								$totalstars = floor( $rating );
								$halfstar = round( $rating * 2 ) % 2;
								$stars = "";

								for( $i=0; $i<$totalstars; $i++ ){
								    $stars .= '<img src="'.plugin_dir_url("library-book-search/assets/images/",  __FILE__ ).'images/star.png" alt="Whole Star">';
								}
								//img tag for half star for decimal values
								if( $halfstar ){
								    $stars .= '<img src="'.plugin_dir_url("library-book-search/assets/images/",  __FILE__ ).'images/half-star.png" alt="Whole Star">';
								}

								echo '<td>'.$stars.'</td>';
								echo "</tr>";
						    $j++;	
						    endwhile; ?>
						    
						<?php wp_reset_postdata();
						endif;

						?>
				       </tbody>
				    </div>
				</table>
			</div><?php
		}

		public function lbs_ajaxfilter_function(){
			parse_str($_POST['searchinput'], $post_data); 
			$meta_query = array();
			if((isset($post_data['bookratings']) && $post_data['bookratings'] != "") && (isset($post_data['bookprice']) && $post_data['bookprice'] != 0 )) {
		    	$temp = array('relation' => 'AND');
		    	array_push($meta_query, $temp);
			}
		    if (isset($post_data['bookratings']) && $post_data['bookratings'] != "")
		    {
		        $temp =  array(
	                        'key' => 'lbs_ratings',
	                        'value' => $post_data['bookratings'],
	                        'compare' => '==',
					        'type' => 'NUMERIC'
	                );
		        array_push($meta_query, $temp);
		    }
		    if (isset($post_data['bookprice']) && $post_data['bookprice'] != 0)
		    {
		        $temp =  array(
		                        'key' => 'lbs_price',
						        'value' => $post_data['bookprice'],
						        'compare' => '<=',
						        'type' => 'NUMERIC'
		                    );
		        array_push($meta_query, $temp);
		    }
		    $tax_query = array();
		    if((isset($post_data['bookauthor']) && ($post_data['bookauthor'] != '')) && (isset($post_data['bookpublisher']) &&  ($post_data['bookpublisher'] != ""))) {
		    	$temp = array('relation' => 'AND');
		    	array_push($tax_query, $temp);
			}
			
		    
		    if (isset($post_data['bookpublisher']) && $post_data['bookpublisher'] != "")
		    {
		        $temp =  array(
		                'taxonomy' => 'book_publisher',
		                'field' => 'slug',
		                'terms' => array($post_data['bookpublisher'])
		            );
		        array_push($tax_query, $temp);
		    }
		    if (isset($post_data['bookauthor']) && $post_data['bookauthor'] != "")
		    {
		        $temp =  array(
		                'taxonomy' => 'book_author',
		                'field' => 'name',
		                'terms' => array($post_data['bookauthor'])
		            );
		        array_push($tax_query, $temp);
		    }

			$args = array(
	                'post_type' => 'book',
	                'posts_per_page' => -1,
	                'name' => $post_data['bookname'],
	                'meta_query' => $meta_query,
		            'tax_query' => $tax_query

	        ); 
			global $post;
		    $searchquery = new WP_Query( $args );
			if ( $searchquery->have_posts() ) : $j=1; ?>
				<script type="text/javascript">$('#tableresult').paging({limit:5}); </script>
				<table class="table table-striped table-bordered" id="tableresult">                     
				    <div class="table responsive">
				        <thead>
				            <tr>
				              <th>No.</th>
				              <th>Name</th>
				              <th>Author</th>
				              <th>Publisher</th>
				              <th>Price</th>
				              <th>Ratings</th>	
				            </tr>
				        </thead>
				        <tbody class="searchresponse"><?php
						    while ($searchquery->have_posts()) : $searchquery->the_post();
						            echo "<tr>"; 
									echo '<td>'.$j.'</td>';
									echo '<td><a href="'.get_the_permalink().'">'.get_the_title().'</a></td>';
									$book_author = wp_get_post_terms($post->ID, 'book_author', array("fields" => "names"));
									echo '<td>'.$book_author[0].'</td>';
									$book_publisher = wp_get_post_terms($post->ID, 'book_publisher', array("fields" => "names"));
									echo '<td>'.$book_publisher[0].'</td>';
									echo '<td>'.get_post_meta($post->ID,'lbs_price', true).'</td>';
							    	$rating = get_post_meta($post->ID,'lbs_ratings', true);

									// round down to get number of whole stars needed
									$totalstars = floor( $rating );
									$halfstar = round( $rating * 2 ) % 2;
									$stars = "";

									for( $i=0; $i<$totalstars; $i++ ){
									    $stars .= '<img src="'.plugin_dir_url("library-book-search/assets/images/",  __FILE__ ).'images/star.png" alt="Whole Star">';
									}
									//img tag for half star for decimal values
									if( $halfstar ){
									    $stars .= '<img src="'.plugin_dir_url("library-book-search/assets/images/",  __FILE__ ).'images/half-star.png" alt="Whole Star">';
									}

									echo '<td>'.$stars.'</td>';
									echo "</tr>";
								$j++;	
						    endwhile;
			?>			</tbody>
				    </div>
				</table>
			<?php else: ?>
		        <p class="notice_msg"><?php _e( 'Sorry, but nothing matched your search criteria.'); ?></p>
		  	<?php endif;
			wp_die();
				
		}	
	}	
}
