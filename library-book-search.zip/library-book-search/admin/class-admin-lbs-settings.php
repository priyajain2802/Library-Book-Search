<?php
class LBSSettingsPage
{
    /**
     * Start up
     */
    public function __construct()
    {
        add_action( 'admin_menu', array( $this, 'lbs_setting_page' ) );
        add_action('admin_enqueue_scripts', array($this, 'lbs_admin_style') );
    }

    /**
     * Add options page
     */
    public function lbs_setting_page()
    {
        // This page will be under "Settings"
        add_options_page(
            'Settings', 
            'LBS Settings', 
            'manage_options', 
            'lbs-setting-admin', 
            array( $this, 'lbs_setting_admin_page' )
        );
    }

    /**
     * Options page callback
     */
    public function lbs_setting_admin_page()
    {
        ?>
        <div class="wrap">
            <h1>Library search book</h1>
            <div class="container">
              <h1>LBS search form & listing shortcode</h1>
               <div class="alert alert-success">
                  <strong><mark>[library-search-form]</mark></strong> Please use this shortcode to display library search form on any post or page.
                  <span>You just need to copy and paste this shortcode to any post or page to show its functionality on the front end.</span>
              </div>
              <div class="alert alert-success">
                  <strong><mark>[library-book-listing]</mark></strong> Please use this shortcode to display library books listing on any post or page.
                  <span>You just need to copy and paste this shortcode to any post or page to show its functionality on the front end.</span>
              </div>
            </div>   
        </div>
        <?php
    }
    /*
    * Function to include css in the back-end
    */
    public function lbs_admin_style() {
      wp_enqueue_style('admin-styles',plugins_url( 'assets/css/lbs-settings-admin.css', __FILE__ ), array(), '', false);
    }

}

if( is_admin() )
$lbs_settings_page = new LBSSettingsPage();