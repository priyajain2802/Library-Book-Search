$(document).ready(function () {
	$('#bookratings').prop('selectedIndex',0);
	var rangeSlider = function(){
	  var slider = $('.range-slider'),
	      range = $('.range-slider__range'),
	      value = $('.range-slider__value');
	    
	  slider.each(function(){

	    value.each(function(){
	      var value = $(this).prev().attr('value');
	      $(this).html(value);
	    });

	    range.on('input', function(){
	      $(this).next(value).html(this.value);
	    });
	  });
	};

	rangeSlider();

	$('#tableData').paging({limit:5});
    
   	// Perform AJAX for book search form submit
	$('#search-form').submit(function(event) {
		$("#LoadingImage").show();
		event.preventDefault();
		var formData = $("#search-form").serialize();
	  	jQuery.ajax({
	        url: lbs_ajax_function.ajaxurl,
	        type: "POST", 
	        data: { 
	            'action': 'lbs_filter',
	            'searchinput' : formData
	        },
	        success: function(data){
	        	$("#LoadingImage").hide();
	        	$('#resultdata').html(data);
	        }
    	});

    });

});