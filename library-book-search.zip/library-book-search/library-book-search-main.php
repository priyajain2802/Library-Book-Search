<?php
/*
 * Plugin Name: Library Book Search
 * Description: A simple search plugin for book library. It will allow users to search books with book name, author, publisher, price and book ratings.
 * Author: Priya Jain
 * Version: 1.0.0
 * Author URI: https://stackoverflow.com/users/2633591/priya-jain
 * License: GPL2+
 */
if ( ! defined( 'ABSPATH' ) ) {
    die;
}
/**
* Define Plugin Path
*/
define( 'LBS_PLUGIN_URL', plugins_url('', __FILE__ ) );

if( !class_exists( 'LBS' ) ) {

	class LBS {

		private static $_this;

		private static $_version;

		private static $scripts_version;

		private static $lbs;

		private static $admin_settings;
		
		function __construct() {

			global $wpdb;
		
			self::$_this = $this;

			self::$_version = '1.0.0';

			//Flush rewrite rules on plugin activation	
			register_activation_hook( __FILE__, array( $this, 'lbs_activate_deactivate' ) );

			//Flush rewrite rules on plugin deactivation
			register_deactivation_hook( __FILE__, array( $this, 'lbs_activate_deactivate' ));
			
			// Create CPT books on plugin activation
			add_action('init', array($this,'lbs_book_cpt'));

			// Enqueue scripts and styles
			add_action( 'wp_enqueue_scripts', array( $this, 'lbs_load_js_css' ) );
			
			require ('admin/class-admin-lbs-settings.php');

			require( 'includes/class_library_book_search.php' );

			self::$lbs = new library_book_search();
			
			//call function to display the search form on the front end using shortcode
			add_shortcode( 'library-search-form', array( self::$lbs, 'search_form' ) );

			//call function to display the list of books on the front end using shortcode
			add_shortcode( 'library-book-listing', array( self::$lbs, 'book_listing' ) );

			// AJAX action to handle the search functions
			add_action( 'wp_ajax_lbs_filter', array( self::$lbs, 'lbs_ajaxfilter_function' ) );	
			
			//AJAX action to handle the search functions for nonlogged in users
			add_action( 'wp_ajax_nopriv_lbs_filter', array( self::$lbs, 'lbs_ajaxfilter_function' ) );
		}

		static function this() {
		
			return self::$_this;
		
		}

		/** 
		** Create custom post type for managing books data
		**/
		function lbs_book_cpt() {

			$lbs_labels = array( 
				'name' => __( 'Book', '' ), 
				'singular_name' => __( 'Book', 'LBS' ), 
				'all_items' => __( 'All Books', 'LBS' ), 
				'add_new_item' => __( 'Add New Book', 'LBS' ), 
				'add_new' => __( 'New Book', 'LBS' ), 
				'new_item' => __( 'New Book', 'LBS' ), 
				'edit_item' => __( 'Edit Book', 'LBS' ), 
				'view_item' => __( 'View Book', 'LBS' ), 
				'search_items' => __( 'Search Book', 'LBS' ), 
				'not_found' => __( 'No books found', 'LBS' ), 
				'not_found_in_trash' => __( 'No books found in Trash', 'LBS' ), 
			); 
			$lbs_args = array( 
				'labels' => $lbs_labels, 
				'public' => true, 
				'can_export' => true, 
				'show_in_nav_menus' => false, 
				'show_ui' => true, 
				'show_in_rest' => true, 
				'capability_type' => 'post', 
				'taxonomies' => array('book_author', 'book_publisher'),
		 		'supports' => array('title', 'thumbnail', 'editor'),
		 		'menu_icon' => 'dashicons-book'  
			); 

			register_post_type( 'book', $lbs_args); 

			// Create book author taxonomy
			register_taxonomy( 'book_author', 'book', array( 'label' => __( 'Book Author', 'LBS' ), 'hierarchical' => true, 'show_in_rest' => true, ) ); 
			
			// Create book publisher taxonomy
			register_taxonomy( 'book_publisher', 'book', array( 'label' => __( 'Book Publisher', 'LBS' ), 'hierarchical' => true, 'show_in_rest' => true, ) );

			//Add meta box for ratings
			add_action('add_meta_boxes', array($this, 'lbs_add_rating_price_meta_box' )); 

			//Save rating value in cpt book
			add_action( 'save_post', array($this, 'lbs_ratings_price_save_meta_field' ));

			//To call single book page template from the plugin
			add_filter('single_template', array ($this, 'single_book_template'));

			//To rewrite rules and flush permalink cache
			flush_rewrite_rules();
		}

		/*
		** Flush cache on activation & deactivation
		*/
		function lbs_activate_deactivate() {
		    flush_rewrite_rules();
		}
		
		/**
		** Loading js/css for the LBS plugin
		**/	
		function lbs_load_js_css() {
			//Include CSS			
			wp_enqueue_style('bootstrap',plugins_url( 'assets/css/bootstrap.min.css', __FILE__ ), array(), self::$scripts_version, false);
			wp_enqueue_style('custom-css',plugins_url( 'assets/css/custom.css', __FILE__ ), array(), self::$scripts_version, false);
			//Include JS
			wp_enqueue_script('jquery');
		    wp_enqueue_script('bootstrap-js', plugins_url( 'assets/js/bootstrap.min.js', __FILE__ ), array('jquery'), '3.3.4', true );
			wp_enqueue_script('jquery-paginate', plugins_url( 'assets/js/jquery-paginate.js', __FILE__ ),  array('jquery'), '', true );
			wp_enqueue_script('custom-js', plugins_url( 'assets/js/custom.js', __FILE__ ),  array('jquery'), '', true );
	        wp_localize_script('jquery', 'lbs_ajax_function', array(
		        'ajaxurl'       => admin_url( 'admin-ajax.php' ))
		    );     
	    }

	    /**
	    ** Add meta box for ratings
	    **/
	    function lbs_add_rating_price_meta_box() {
		   add_meta_box(
		       'lbs_ratings_price',       // $id
		       'Ratings & Price',           // $title
		       array( $this,'show_lbs_ratings_price'),  // $callback
		       'book',             	// $page
		       'normal',           	// $context
		       'high'               // $priority
		   );
		}

		//showing custom form fields for ratings
		function show_lbs_ratings_price() {

		    global $post;
		    // Use nonce for verification to secure data sending
		    wp_nonce_field( basename( __FILE__ ), 'lbs_ratings_price_nonce' );

		    // Get the rating data if it's already been entered
			$lbs_ratings = get_post_meta( $post->ID, 'lbs_ratings', true );
			
			// Get the price data if it's already been entered
			$lbs_price = get_post_meta( $post->ID, 'lbs_price', true );

			// Output the ratings field
			echo '<div class="lbs-ratings"><label>Ratings: </label><input type="text" name="lbs_ratings" value="' . esc_textarea( $lbs_ratings )  . '" class=""></div>';
			
			// Output the price field
			echo '<div class="lbs-price"><label>Price: </label><input type="text" name="lbs_price" value="' . esc_textarea( $lbs_price )  . '" class=""></div>';

		}

		//now we are saving the data
		function lbs_ratings_price_save_meta_field( $post_id ) {
			// verify nonce
			if (!isset($_POST['lbs_ratings_price_nonce']) || !wp_verify_nonce($_POST['lbs_ratings_price_nonce'], basename(__FILE__))){
			  return 'nonce not verified';
			}

			// check autosave
			if ( wp_is_post_autosave( $post_id ) ){
			  return 'autosave';
			}

			//check post revision
			if ( wp_is_post_revision( $post_id ) ){
			  return 'revision';
			}

	  		// check permissions
		  	if ( 'book' == $_POST['post_type'] ) {
			    if ( ! current_user_can( 'edit_page', $post_id ) ){
			       return 'cannot edit page';
			    }
			    elseif ( ! current_user_can( 'edit_post', $post_id ) ) {
			       return 'cannot edit post';
			    }
				if ( isset($_POST['lbs_ratings']) ) {        
				   update_post_meta($post_id, 'lbs_ratings', sanitize_text_field( $_POST['lbs_ratings']));      
				} 
				if ( isset($_POST['lbs_price']) ) {        
				   update_post_meta($post_id, 'lbs_price', sanitize_text_field( $_POST['lbs_price']));      
				}  
			}		  

		}

		function single_book_template($single) {
			global $wp_query, $post;
		    /* Checks for single template by post type */
		    if ( $post->post_type == 'book' ) {
		        if ( file_exists( plugin_dir_path( __FILE__ ) . "includes/single-book.php" ) ) {
		            return plugin_dir_path( __FILE__ ) . "includes/single-book.php";
		        }
		    }

		    return $single;

		}
	}	
}	

new LBS();